#include <stdint.h>

uint8_t adjustments[10] = {1, -1, 2, 2, 4, 1, -1, 4, -2, 1}; // Some values to fake an unreliable motor!
uint8_t alarms[10] = {0, 1, 1, 3, 0, 5, 4, 4, 0, 1};
