#include <stdint.h>

uint8_t adjustments[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
uint8_t alarms[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
